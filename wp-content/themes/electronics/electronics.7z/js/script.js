// alert('it works');
// var x = jQuery("[name='electronics_types']");
// var x = 'hello';
// alert(x);
// jQuery("body").css("background", "green");
 

// jQuery("#ajax_product_filter_button_test").click(function(){alert('click');});


