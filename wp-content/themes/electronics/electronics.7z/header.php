<body>
	<header>
	HEADER
<?php
wp_nav_menu('header_menu');
// echo get_stylesheet_directory_uri();
echo get_template_directory_uri();
wp_head();
?>
</header>